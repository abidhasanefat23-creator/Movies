package com.animeverse.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
data class Anime(val id:Int,val title:String,val genre:String,val year:String,val desc:String,val glyph:String)
val demo=listOf(
 Anime(1,"Beyond the Horizon","Fantasy","2026","A mapmaker discovers forgotten worlds hidden among the stars.","幻"),
 Anime(2,"Neon Reverie","Sci-Fi","2025","A courier in a memory-powered city receives messages from tomorrow.","ネ"),
 Anime(3,"The Paper Kingdom","Adventure","2026","Two siblings enter a storybook kingdom where choices change the ending.","紙"),
 Anime(4,"Quiet Comets","Drama","2024","A gentle story about friendship, music and finding your direction.","星"))
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{Screen()}}}
@Composable fun Screen(){
 val bg=Color(0xFF090914); val purple=Color(0xFFAA82FF); val panel=Color(0xFF171629)
 var query by remember{mutableStateOf("")}; var fav by remember{mutableStateOf(setOf<Int>())}
 var tab by remember{mutableStateOf("Home")}; var chosen by remember{mutableStateOf<Anime?>(null)}
 MaterialTheme(colorScheme=darkColorScheme(primary=purple,background=bg,surface=panel)){
 Surface(Modifier.fillMaxSize(),color=bg){Column{
 Row(Modifier.fillMaxWidth().padding(20.dp),verticalAlignment=Alignment.CenterVertically){
 Text("✦ ANIME",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Black);Text("VERSE",color=purple,fontSize=21.sp,fontWeight=FontWeight.Black);Spacer(Modifier.weight(1f));Text("ANDROID APP",color=purple,fontSize=10.sp)}
 if(chosen==null){
 Column(Modifier.padding(horizontal=18.dp)){
 Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF492766),Color(0xFF171629))),RoundedCornerShape(20.dp)).padding(22.dp)){
 Column{Text("YOUR NEXT ADVENTURE",color=Color(0xFFE5B8FF),fontSize=10.sp);Spacer(Modifier.height(8.dp));Text("Stories beyond\nimagination.",color=Color.White,fontSize=32.sp,fontWeight=FontWeight.ExtraBold);Text("Discover creator-owned and licensed anime.",color=Color.LightGray,fontSize=12.sp)}}
 Spacer(Modifier.height(14.dp))
 OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),placeholder={Text("Search anime...")},singleLine=true)
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Home","Favorites").forEach{FilterChip(selected=tab==it,onClick={tab=it},label={Text(it)})}}
 }
 val rows=demo.filter{it.title.contains(query,true)&&(tab!="Favorites"||fav.contains(it.id))}
 LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 item{Text("EXPLORE ANIME",color=purple,fontWeight=FontWeight.Bold,letterSpacing=2.sp)}
 items(rows){a->Row(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(16.dp)).clickable{chosen=a}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
 Box(Modifier.size(78.dp,96.dp).background(Brush.linearGradient(listOf(Color(0xFF69448C),Color(0xFF20203C))),RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Text(a.glyph,color=Color.White,fontSize=38.sp)}
 Column(Modifier.weight(1f).padding(horizontal=12.dp)){Text(a.title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=15.sp);Text("${a.genre} • ${a.year}",color=purple,fontSize=11.sp);Text(a.desc,color=Color.LightGray,fontSize=11.sp,maxLines=2);Text("VIEW DETAILS →",color=purple,fontSize=10.sp)}
 IconButton(onClick={fav=if(fav.contains(a.id))fav-a.id else fav+a.id}){Icon(if(fav.contains(a.id))Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=purple)}
 }}
 if(rows.isEmpty())item{Text("No anime found or no favorites saved.",color=Color.LightGray)}
 item{Text("Demo catalogue only. Add only videos you own or are licensed to stream.",color=Color.Gray,fontSize=10.sp)}
 }
 }else{
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)){
 Text("‹ BACK",color=purple,modifier=Modifier.clickable{chosen=null}.padding(vertical=12.dp))
 Box(Modifier.fillMaxWidth().height(190.dp).background(Brush.linearGradient(listOf(Color(0xFF69448C),Color(0xFF20203C))),RoundedCornerShape(20.dp)),contentAlignment=Alignment.Center){Text(chosen!!.glyph,color=Color.White,fontSize=90.sp)}
 Text(chosen!!.genre+" • "+chosen!!.year,color=purple,modifier=Modifier.padding(top=16.dp))
 Text(chosen!!.title,color=Color.White,fontSize=28.sp,fontWeight=FontWeight.Bold)
 Text(chosen!!.desc,color=Color.LightGray,modifier=Modifier.padding(vertical=12.dp))
 Button(onClick={},colors=ButtonDefaults.buttonColors(containerColor=purple)){Text("▶ Play Episode 01")}
 Text("EPISODES",color=purple,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=24.dp))
 Text("Episode 01 • Pilot",color=Color.White,modifier=Modifier.padding(top=12.dp))
 Text("Video streaming needs a licensed video URL and secure backend.",color=Color.LightGray,fontSize=12.sp)
 }
 }
 }}
}
