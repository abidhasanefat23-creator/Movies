এটি ওয়েবসাইট নয়; Kotlin + Jetpack Compose দিয়ে তৈরি Native Android app source project।
APK এখনো build করা হয়নি। Android ফোন থেকে APK পেতে ZIP-টি GitHub repository-তে upload করে Actions tab থেকে Build AnimeVerse APK workflow চালাও। সফল হলে Artifacts থেকে AnimeVerse-debug-apk.zip download করে extract করে app-debug.apk install করো।
বর্তমানে demo anime catalogue, search, favorites (session-only), details screen আছে। Episode streaming এখনো সংযুক্ত নয়। ভিডিও চালাতে নিজের/লাইসেন্সকৃত ভিডিও URL, secure backend, admin login ও hosting দরকার। Demo titles fictional.
